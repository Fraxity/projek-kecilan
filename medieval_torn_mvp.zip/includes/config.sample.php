<?php
// Copy to config.php and set credentials
return [
    'db' => [
        'host' => '127.0.0.1',
        'name' => 'medieval_torn',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4',
    ],
    'app_key' => 'change_me_random_string' // used for CSRF
];
